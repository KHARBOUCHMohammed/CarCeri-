<footer class="page-footer font-small bg-footer">

  <div class="footer-copyright text-center py-3">© <?php echo date('Y'); ?> Copyright:
    <a>Labrak Yanis & Vougeot Valentin</a>
  </div>

</footer>