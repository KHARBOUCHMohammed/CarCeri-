<div class="centeredSearch">

<?php include($nameApp . "/view/fromToBar.php"); ?>

<div class="text-center">
    <img src="undraw_not_found_60pq.svg" style="width: 25em;">
    <h1 class="titleSearch">Pas de voyages trouver.</h1>
</div>

</div>