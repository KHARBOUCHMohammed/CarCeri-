find . -type f -exec chmod o+r {} \;
find . -type d -exec chmod o+r {} \;